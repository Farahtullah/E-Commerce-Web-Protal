from django.contrib.auth import authenticate, login, get_user_model
from django.views.generic import CreateView, FormView
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.utils.http import is_safe_url
from django.contrib.auth.models import User
#import django.core.context_processors.auth  

from .forms import LoginForm, RegisterForm, GuestForm, SellerForm
from .models import GuestEmail, Seller, User
from .signals import user_logged_in




def guest_register_view(request):
    form = GuestForm(request.POST or None)
    context = {
        "form": form
    }
    next_ = request.GET.get('next')
    next_post = request.POST.get('next')
    redirect_path = next_ or next_post or None
    if form.is_valid():
        email       = form.cleaned_data.get("email")
        new_guest_email = GuestEmail.objects.create(email=email)
        request.session['guest_email_id'] = new_guest_email.id
        if is_safe_url(redirect_path, request.get_host()):
            return redirect(redirect_path)
        else:
            return redirect("/register/")
    return redirect("/register/")



#class SellerView(FormView):
 #   form_class = SellerForm
 #   template_name = 'seller_page.html' 
 #   success_url = '/seller/'
 #   def form_valid(self, form):
 #       request = self.request
 #       next_ = request.GET.get('next')
 #       next_post = request.POST.get('next')
 #       redirect_path = next_ or next_post or None
 #       form = SellerForm(request.POST or None)
 #       if form.is_valid():
 #           instance = form.save(commit=False)
 #           user     = User.objects.all()
 #           if user is not None:
 #              instance.user = user
 #              instance.save()
 #              request.session['user_id'] = instance.id
 #           else:
 #               print("Error here")
 #               return redirect("/seller/")
 #
 #           if is_safe_url(redirect_path, request.get_host()):
 #               return redirect(redirect_path)
 #       return super(SellerView, self).form_invalid(form)







#class SellerRegisterView(CreateView):
#    form_class = SellerForm
#    template_name = 'accounts/register.html'
#    success_url = '/seller/login/'




class SellerView(FormView):
    form_class    = SellerForm
    template_name = 'seller_page.html'
    success_url = '/seller/'

    
 #   def form_valid(self, form):
 #       request = self.request
 #       form = SellerForm(request.POST or None)
 #       instance = form.save(commit=False)
 #       user = User.objects.all() 
 #       instance.user    = User.objects.get(id=)
 #       instance.save()
 #       request.session['user_id'] = instance.id

 #       return super(SellerView, self).form_invalid(form)







 #       context = {
 #           "form": form
 #       }
 #      next_ = request.GET.get('next')
 #       next_post = request.POST.get('next')
 #       redirect_path = next_ or next_post or None
 #       if form.is_valid():
 #           shopname       = form.cleaned_data.get("shopname")
 #           location       = form.cleaned_data.get("location")
 #           new_user    = Seller.objects.create(shopname=shopname, location=location)
 #           request.session['user_id'] = new_user.id
 #       return redirect("/seller/")


  #  form_class    = SellerForm

  #  template_name = 'seller_page.html'
 #   success_url = '/seller/'
   # def form_valid(self, form):
  #      request = self.request
   #     form                = SellerForm(request.POST)
  # #     user                = User.objects.new_or_get(request)
  #  #    user                = User()
  # #     user_id             = int(request.POST['id'])
  # #     user_id             = request.POST.get("id")
  #  #    uid                 = request.session['mid']
  #      seller_cont.user    = User.objects.get(id=2)
  #      seller_cont.upvote  = 0
   #     seller_cont.downvote = 0
  #      seller_cont.save()
  #      return super(SellerView, self).form_invalid(form)


        
class SellerLoginView(FormView):
    form_class = LoginForm
    success_url = '/seller/'
    template_name = 'accounts/login.html'

    def form_valid(self, form):
        request = self.request
        next_ = request.GET.get('next')
        next_post = request.POST.get('next')
        redirect_path = next_ or next_post or None
        email  = form.cleaned_data.get("email")
        password  = form.cleaned_data.get("password")
        user = authenticate(request, username=email, password=password)
        if user is not None:
            if user.user_type=='Seller':
                login(request, user)
                user_logged_in.send(user.__class__, instance=user, request=request)
                try:
                    del request.session['guest_email_id']
                except:
                    pass
                if is_safe_url(redirect_path, request.get_host()):
                    return redirect(redirect_path)
                else:
                    return redirect("/seller/")
        return super(SellerLoginView, self).form_invalid(form)    

    


class LoginView(FormView):
    form_class = LoginForm
    success_url = '/'
    template_name = 'accounts/login.html'

    def form_valid(self, form):
        request = self.request
        next_ = request.GET.get('next')
        next_post = request.POST.get('next')
        redirect_path = next_ or next_post or None
        email  = form.cleaned_data.get("email")
        password  = form.cleaned_data.get("password")
        user = authenticate(request, username=email, password=password)
        if user is not None:
            if user.user_type=='Buyer':
                login(request, user)
                user_logged_in.send(user.__class__, instance=user, request=request)
                try:
                    del request.session['guest_email_id']
                except:
                    pass
                if is_safe_url(redirect_path, request.get_host()):
                    return redirect(redirect_path)
                else:
                    return redirect("/")
        return super(LoginView, self).form_invalid(form)


class RegisterView(CreateView):
    form_class = RegisterForm
    template_name = 'accounts/register.html'
    success_url = '/login/'




# def login_page(request):
#     form = LoginForm(request.POST or None)
#     context = {
#         "form": form
#     }
#     next_ = request.GET.get('next')
#     next_post = request.POST.get('next')
#     redirect_path = next_ or next_post or None
#     if form.is_valid():
#         username  = form.cleaned_data.get("username")
#         password  = form.cleaned_data.get("password")
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             login(request, user)
#             try:
#                 del request.session['guest_email_id']
#             except:
#                 pass
#             if is_safe_url(redirect_path, request.get_host()):
#                 return redirect(redirect_path)
#             else:
#                 return redirect("/")
#         else:
#             # Return an 'invalid login' error message.
#             print("Error")
#     return render(request, "accounts/login.html", context)

# User = get_user_model()
# def register_page(request):
#     form = RegisterForm(request.POST or None)
#     context = {
#         "form": form
#     }
#     if form.is_valid():
#         form.save()
#     return render(request, "accounts/register.html", context)