from django import forms
from django.contrib.auth import get_user_model
from .models import Product
from accounts.models import User

class AddProductForm(forms.ModelForm):

    class Meta:
        model = Product
        fields = ('title', 'slug', 'description', 'price', 'image',) 
        
    



