# from django.views import ListView
from django.http import Http404, JsonResponse
from django.views.generic import ListView, DetailView, CreateView
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render,redirect

from analytics.mixins import ObjectViewedMixin

from carts.models import Cart

from .models import Product

from .forms import AddProductForm

class ProductFeaturedListView(ListView):
    template_name = "products/list.html"

    def get_queryset(self, *args, **kwargs):
        request = self.request
        return Product.objects.all().featured()


class ProductFeaturedDetailView(ObjectViewedMixin, DetailView):
    queryset = Product.objects.all().featured()
    template_name = "products/featured-detail.html"

    # def get_queryset(self, *args, **kwargs):
    #     request = self.request
    #     return Product.objects.featured()



class ProductListView(ListView):
    template_name = "products/list.html"

    # def get_context_data(self, *args, **kwargs):
    #     context = super(ProductListView, self).get_context_data(*args, **kwargs)
    #     print(context)
    #     return context

    def get_context_data(self, *args, **kwargs):
        context = super(ProductListView, self).get_context_data(*args, **kwargs)
        cart_obj, new_obj = Cart.objects.new_or_get(self.request)
        context['cart'] = cart_obj
        return context

    def get_queryset(self, *args, **kwargs):
        request = self.request
        return Product.objects.all()


def product_list_view(request):
    queryset = Product.objects.all()
    context = {
        'object_list': queryset
    }
    return render(request, "products/list.html", context)



class ProductDetailSlugView(ObjectViewedMixin, DetailView):
    queryset = Product.objects.all()
    template_name = "products/detail.html"

    def get_context_data(self, *args, **kwargs):
        context = super(ProductDetailSlugView, self).get_context_data(*args, **kwargs)
        cart_obj, new_obj = Cart.objects.new_or_get(self.request)
        context['cart'] = cart_obj
        return context

    def get_object(self, *args, **kwargs):
        request = self.request
        slug = self.kwargs.get('slug')

        #instance = get_object_or_404(Product, slug=slug, active=True)
        try:
            instance = Product.objects.get(slug=slug, active=True)
        except Product.DoesNotExist:
            raise Http404("Not found..")
        except Product.MultipleObjectsReturned:
            qs = Product.objects.filter(slug=slug, active=True)
            instance = qs.first()
        except:
            raise Http404("Uhhmmm ")
        return instance



class ProductDetailView(ObjectViewedMixin, DetailView):
    #queryset = Product.objects.all()
    template_name = "products/detail.html"

    def get_context_data(self, *args, **kwargs):
        context = super(ProductDetailView, self).get_context_data(*args, **kwargs)
        print(context)
        # context['abc'] = 123
        return context

    def get_object(self, *args, **kwargs):
        request = self.request
        pk = self.kwargs.get('pk')
        instance = Product.objects.get_by_id(pk)
        if instance is None:
            raise Http404("Product doesn't exist")
        return instance

    # def get_queryset(self, *args, **kwargs):
    #     request = self.request
    #     pk = self.kwargs.get('pk')
    #     return Product.objects.filter(pk=pk)


def product_detail_view(request, pk=None, *args, **kwargs):
    # instance = Product.objects.get(pk=pk, featured=True) #id
    # instance = get_object_or_404(Product, pk=pk, featured=True)
    # try:
    #     instance = Product.objects.get(id=pk)
    # except Product.DoesNotExist:
    #     print('no product here')
    #     raise Http404("Product doesn't exist")
    # except:
    #     print("huh?")

    instance = Product.objects.get_by_id(pk)
    if instance is None:
        raise Http404("Product doesn't exist")
    #print(instance)
    # qs  = Product.objects.filter(id=pk)

    # #print(qs)
    # if qs.exists() and qs.count() == 1: # len(qs)
    #     instance = qs.first()
    # else:
    #     raise Http404("Product doesn't exist")

    context = {
        'object': instance
    }
    return render(request, "products/detail.html", context)



class SelleraddproductView(CreateView):
    form_class    = AddProductForm
    template_name = 'products/addproduct.html'
    success_url = '/seller/'

 #   def form_valid(self, form):
 #       request = self.request
 #       next_ = request.GET.get('next')
 #       next_post = request.POST.get('next')
 #       redirect_path = next_ or next_post or None        
 #       user_id = request.POST.get('user_id')
 #       if user_id is not None:
 #           try:
 #               user_obj = User.objects.get(id=user_id)
 #           except User.DoesNotExist:
 #               print("Show message to user, product is gone?")
 #               return redirect("/seller/")
 #           product_obj, new_obj = Product.objects.new_or_get(request)
 #           if user_obj in product_obj.users.all():
 #               product_obj.users.remove(user_obj)
 #               added = False
 #           else:
 #               product_obj.users.add(user_obj) # cart_obj.products.add(product_id)
 #               added = True
 #           request.session['product_items'] = product_obj.users.count()

 #           if request.is_ajax(): # Asynchronous JavaScript And XML / JSON
 #               print("Ajax request")
 #               json_data = {
 #               "added": added,
 #               "removed": not added,
 #               "cartItemCount": product_obj.users.count()
 #               }
 #               return JsonResponse(json_data, status=200) 

 #       return super(SelleraddproductView, self).form_invalid(form)

    
        
            

        
        
            
        
            
        

    


   
        
